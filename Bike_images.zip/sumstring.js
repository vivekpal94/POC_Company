function findSum(str)
{
    let t =0 ;
    let s = 0;
    for (let i = 0; i < str.length; i++) {
        let ch = str[i];
        // if current character is a digit
        if (!isNaN(String(ch) * 1))
            t += ch;
        // if current character is an alphabet
        else {
            // increment sum by number found earlier
            // (if any)
            s += parseInt(t);
            // reset temporary string to empty
            t = "0";
        }
    }
    // numbers
    return s + parseInt(t);
}
let str = "12abc20yz68";
// Function call
document.write(findSum(str));
