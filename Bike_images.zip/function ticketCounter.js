function ticketCounter(N,k)
{
    var arr=[];
    for(var i=0;i<N;i++)
    {
        arr[i]=i+1;
    }
    var i=1;
    while (arr.length>k)
    {
        if(i%2!=0)
        {
            arr.splice(0,k);
        } else  {
            arr.splice(-k)
        }
        i++;
    }
    if(i%2!=0) {
        return arr.pop();
    } else{
        return arr[0];
    }
}
console.log(ticketCounter(9,3));
console.log(ticketCounter(25,7));